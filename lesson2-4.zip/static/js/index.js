async function christmas() {
    alert("1. Происходит сбор денег на вечеринку...")
    let x = await new Promise((resolve, reject) => {
        setTimeout(() => {
            let money = prompt("Введите сумму:")
            if (money >= 100) {
                alert("2. Поступили деньги в нужно объеме!")
                resolve() // подтверждение, что деньги собраны
            } else {
                alert("2.1 Денег недостаточно!!")
                reject()
            }

        }, 5000) // 2 
    })
    alert("3. сбор окончен!")
    return x
}

christmas()
    .then((data) => {
        alert("4. Сумма собрана! Вечеринка!") // 1
    })
    .catch(() => {
        alert("4.1 Денег недостаточно!") // 1
    })